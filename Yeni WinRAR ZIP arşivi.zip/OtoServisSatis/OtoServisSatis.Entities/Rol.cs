﻿namespace OtoServisSatis.Entities
{
    public class Rol : IEntity
    {
        public int ID { get; set; }
        public string Adi { get; set; }


    }
}
