﻿namespace OtoServisSatis.Entities
{
    public class Marka : IEntity
    {
        public int ID { get; set; }
        public string Adi { get; set; }
    }
}
